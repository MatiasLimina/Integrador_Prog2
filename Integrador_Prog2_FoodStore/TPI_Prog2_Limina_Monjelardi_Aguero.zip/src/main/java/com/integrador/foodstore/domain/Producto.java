package com.integrador.foodstore.domain;

public class Producto extends Base {
    private String nombre;
    private Double precio;
    private String descripcion;
    private int stock;
    private String imagen;
    private Boolean disponible;
    private Categoria categoria; // Relación N:1 con Categoria (Cada producto pertenece a una categoría)

    public Producto() {
        super();
    }

    // Constructor para la creación de nuevos productos desde el menú
    public Producto(String nombre, Double precio, String descripcion, int stock, String imagen, Boolean disponible, Categoria categoria) {
        super();
        this.nombre = nombre;
        setPrecio(precio);
        this.descripcion = descripcion;
        setStock(stock);
        this.imagen = imagen; // Se mapea directo al atributo disponible
        this.disponible = disponible;
        this.categoria = categoria;
    }

    // Constructor completo para el mapeo desde los resultados de la base de datos (DAO)
    public Producto(Long id, boolean eliminado, java.time.LocalDateTime createdAt, String nombre, Double precio,
                    String descripcion, int stock, String imagen, Boolean disponible, Categoria categoria) {
        super(id, eliminado, createdAt);
        this.nombre = nombre;
        setPrecio(precio);
        this.descripcion = descripcion;
        setStock(stock);
        this.imagen = imagen;
        this.disponible = disponible;
        this.categoria = categoria;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Double getPrecio() { return precio; }
    public void setPrecio(Double precio) {
        if (precio != null && precio < 0) {
            throw new IllegalArgumentException("El precio del producto no puede ser negativo.");
        }
        this.precio = precio;
    }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public int getStock() { return stock; }
    public void setStock(int stock) {
        if (stock < 0) {
            throw new IllegalArgumentException("El stock del producto no puede ser negativo.");
        }
        this.stock = stock;
    }

    public String getImagen() { return imagen; }
    public void setImagen(String imagen ) { this.imagen = imagen; }

    public Boolean getDisponible() { return disponible; }
    public void setDisponible(Boolean disponible) { this.disponible = disponible; }

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }

    @Override
    public String toString() {
        String catNombre = (categoria != null) ? categoria.getNombre() : "Sin Categoría";
        return "Producto [ID: " + getId() + " | Nombre: " + nombre + " | Precio: $" + precio +
                " | Stock: " + stock + " | Categoría: " + catNombre + "]";
    }
}